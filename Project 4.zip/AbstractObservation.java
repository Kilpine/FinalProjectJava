/**
 * 
 * @author Alexi Musick
 * 
 * 
 * @version 12-6-2018
 * Project 4
 * 
 * 
 */
public abstract class AbstractObservation {
    
    protected boolean valid;
    
    protected AbstractObservation()
    {
        
    }
    
    
    public abstract boolean isValid();
    
}