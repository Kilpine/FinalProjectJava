import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
/**
 * 
 * @author Alexi Musick
 * 
 * 
 * @version 12-6-2018
 * Project 4
 * 
 * Observation test for the Observation class
 */
public class ObservationTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testGetValue() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testIsValid() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testGetStid() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testToString() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testObservation() {
        fail("Not yet implemented");
    }

}