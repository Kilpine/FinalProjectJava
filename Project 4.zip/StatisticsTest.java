import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;
/**
 * 
 * @author Alexi Musick
 * 
 * 
 * @version 12-6-2018
 * Project 4
 * 
 * test statistics class
 */
public class StatisticsTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testConstructor() {
        fail("Not yet implemented");
    }


    @Test
    public void testOverloadConstructor() {
        fail("Not yet implemented");
    }


    @Test
    public void testCreateDataFromString() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testCreateDataFromDate() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testGetNumberOfReportingStations() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testGetUTCDate() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testNewerThan() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testOlderThan() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testSameAs() {
        fail("Not yet implemented");
    }
    
    @Test
    public void testToString() {
        fail("Not yet implemented");
    }
    
    

}
